import numpy as np

if __name__ == "__main__":
    np.random.default_rng(seed=123)
    num = np.random.rand()
    print(f'Random float: {num}')
    dice = np.random.randint(1, 7, 2)
    print(f'Random integer 1: {dice[0]}')
    print(f'Random integer 2: {dice[1]}')

    level = 50
    print(f'Before throw step = {level}')
    dice_roll = np.random.randint(1, 7)
    print(f'After throw dice = {dice_roll}')
    if dice_roll < 3:
        level = level - 1
    elif dice_roll < 6:
        level = level + 1
    else:
        dice_roll = np.random.randint(1, 7)
        level = level + dice_roll

    print(f'After throw step = {level}')
